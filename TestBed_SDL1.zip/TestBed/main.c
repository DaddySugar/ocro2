#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "treatment.h"


int main(int argc, char ** argv)
{
	SDL_Surface * img = load_image("images/pdf_test.bmp");
	greyscale(img);
	display_image(img);
	wait_for_keypressed();
	//greyscale(img);
	//makeitblackandwhite(img,img->w,img->h);
	return 0;
}
