#ifndef DETECTION_H
#define DETECTION_H



void  Line_Detection(SDL_Surface* img); 


#endif
