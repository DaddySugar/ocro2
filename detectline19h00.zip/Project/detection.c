#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "treatment.h"
#include "detection.h"


/* Draws a red line on the image at certain height between point 'A' and 'B'
 * PARAM : 
 * img : Simply the image 
 * start_$ : Point 'A'
 * end_$ : Point 'B' 
 * int $ : Height or width
 */











void Line_Detection(SDL_Surface* img)
{
	Uint8 r,g,b;
	Uint32 pixel;
	int checked;
	int x;
	for(int y=0;y<img->h;y++)
		{
			checked=0;
			for(int x=0;x<img->w;x++)
			{
				pixel = getpixel(img,x,y);
				SDL_GetRGB(pixel,img->format,&r,&g,&b);
				if(r==0 && g==0 && b==0)
				{
					checked=1;
					break;
				}
				
			}
			if (checked==0)
			{
				for (int b=0; b < img->w; b++) 
				{
					putpixel(img, b, y, SDL_MapRGB(img->format, 255, 0, 0));
				}
			}
		}
	}


