



SDL_Surface*greyscale(SDL_Surface* img);
