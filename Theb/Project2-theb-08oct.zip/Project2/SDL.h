

void init_sdl();
Uint32 getpixel(SDL_Surface *surface,int x, int y);
void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel);

