#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>


SDL_Surface *load_image(char *path) {
  SDL_Surface          *img;
  // Load an image using SDL_image with format detection
  img = SDL_LoadBMP(path);
  if (!img)
    // If it fails, die with an error message
    printf("can't load");
  return img;
}

SDL_Surface *display_image(SDL_Surface* image)
{
    int quit = 0;
    SDL_Event event;
 
    SDL_Init(SDL_INIT_VIDEO);
 
    SDL_Window * window = SDL_CreateWindow("SDL2 Displaying Image",
        SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, 0);
 
    SDL_Renderer * renderer = SDL_CreateRenderer(window, -1, 0);
    SDL_Texture * texture = SDL_CreateTextureFromSurface(renderer, image);
 
    while (!quit)
    {
        SDL_WaitEvent(&event);
 
        switch (event.type)
        {
            case SDL_QUIT:
                quit = 1;
                break;
        }
 
        //SDL_Rect dstrect = { 5, 5, 320, 240 };
        //SDL_RenderCopy(renderer, texture, NULL, &dstrect);
        SDL_RenderCopy(renderer, texture, NULL, NULL);
        SDL_RenderPresent(renderer);
    }
 
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(image);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
 
    SDL_Quit();
}
/*
void grey_scale(SDL_Surface *img)
{
	Uint8 r = 0;
	Uint8 g = 0;
	Uint8 b = 0;
	int x = 0;
	int y = 0;
	Uint32 pixel;
	while (x != img->w)
	{
		while (y != img->h)
		{
			pixel = getpixel(img, x, y);
			SDL_GetRGB(pixel, img->format, &r, &g, &b);
			if ((r + g + b)/3 >= 127)
			{
			r = 255;
			g = 255;
			b = 255;
			pixel = SDL_MapRGB(img->format, r, g, b);			// La double boucle est 100% correcte (certain)
			putpixel(img, x, y, pixel);
			}
			else
			{
			r = 0;
			g = 0;
			b = 0;
			pixel = SDL_MapRGB(img->format, r, g, b);			// La double boucle est 100% correcte (certain)
			putpixel(img, x, y, pixel);
			}
			y++;	
		}
		y = 0;
		x++;
	}
	display_image(img);
}
*/
