#ifndef treatment
#define treatment

SDL_Surface* load_image(char *path) ;
SDL_Surface* display_image(SDL_Surface* image);
//void grey_scale(SDL_Surface *img);

#endif
